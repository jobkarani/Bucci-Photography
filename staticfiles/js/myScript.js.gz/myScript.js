// $(window).load(function () {
 
 
//     var $container = $('#craft-images');
     
//     $container.masonry({
//     itemSelector: '.image-box',
//     columnWidth: '.image-box'
//     });

 
// }); 
